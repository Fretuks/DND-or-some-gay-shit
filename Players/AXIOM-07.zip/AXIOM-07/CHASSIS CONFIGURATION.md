## CC-01 - Integrity Frame
**HP:** 12  
**Posture:** 14
-> Lightweight exoskeletal structure. Minimal plating. 
## CC-02 - Ether Containment Battery
**Ether Capacity:** 30
-> Visible containment chamber adjacent to Life Orb housing.  
## CC-03 - Cognitive Stability Matrix
**Sanity:** 9
-> Artificially stabilized consciousness. Subject experiences Depth exposure normally, though breakdown manifests as behavioral instability rather than emotional collapse.
