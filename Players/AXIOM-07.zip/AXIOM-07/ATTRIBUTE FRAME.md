## AF-01 - Physical Output Engine
- **Strength:** 16
- **Dexterity:** 18
- **Constitution:** 14
-> Designed for explosive acceleration and mid-combat repositioning.
## AF-02 - Cognitive Engine
- **Intelligence:** 13
- **Willpower:** 12
- **Charisma:** 8
->Curiosity-driven processing core. Social subroutines underdeveloped.